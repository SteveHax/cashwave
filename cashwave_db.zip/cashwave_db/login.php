CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  phone VARCHAR(12) NOT NULL,
  password VARCHAR(255) NOT NULL
);




<?php
if (isset($_POST['submit'])) {
   $phone = $_POST['phone'];
   $password = $_POST['password'];
   
   // Connect to MySQL database
   $conn = mysqli_connect('localhost', 'your_username', 'your_password', 'your_database');
   
   // Check if connection was successful
   if (!$conn) {
      // die("Connection failed: " . mysqli_connect_error());
      exit();
   }
   
   // Query for checking if the user exists
   $sqlQuery = "SELECT * FROM users WHERE phone = '$phone' AND password = '$password'";
   
   // Execute query
   $result = mysqli_query($conn, $sqlQuery);
   
   // Check if the user exists
   if (mysqli_num_rows($result) > 0) {
      // The user exists
      // Redirect user to another page
   } else {
      // The user does not exist
      echo "The user does not exist. Please try again.";
   }
   
   // Close the connection
   mysqli_close($conn);
}
?>