<?php
// Connect to MySQL database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "database_name";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get withdrawal information
$accountBalance = 5;
$withdrawalAmount = parseInt($_POST['withdrawalAmount']);
$network = $_POST['network'];
$accountName = $_POST['accountName'];
$uniqueId = $_POST['uniqueId'];
$timestamp = Math.floor(Date.now() / 1000);

if ($withdrawalAmount < 50) {
    // Insufficient funds
    return;
}

if ($accountBalance - $withdrawalAmount < 0) {
    // Insufficient funds
    return;
}

// Insert withdrawal information into the database
$sql = "INSERT INTO withdrawals (withdrawalAmount, network, accountName, uniqueId, timestamp)
VALUES ($withdrawalAmount, '$network', '$accountName', '$uniqueId', $timestamp)";

if ($conn->query($sql) === TRUE) {
   echo "New withdrawal created successfully";
} else {
   echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>


The following code creates a table called "withdrawals"

CREATE TABLE withdrawals (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    withdrawalAmount INT NOT NULL,
    network VARCHAR(30) NOT NULL,
    accountName VARCHAR(30) NOT NULL,
    uniqueId VARCHAR(5) NOT NULL,
    timestamp INT NOT NULL
);