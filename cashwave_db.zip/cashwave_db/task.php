<?php
// Establishing the database connection
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'task_db';

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    echo "Connection Error: " . mysqli_connect_error();
}
 
//Creating the table
$sql = "CREATE TABLE task(
id INT (11) AUTO_INCREMENT PRIMARY KEY,
principal INT (11) NOT NULL,
profit INT (11) NOT NULL
)";

$query = mysqli_query($conn, $sql);

if ($query) {
    echo "Table created successfully";
} else {
    echo "Error creating table: " . mysqli_error($conn);
}
 
//Inserting data into the table
$sql2 = "INSERT INTO task(principal, profit) VALUES 
(50, 5),
(100, 10),
(200, 20),
(250, 25),
(500, 55),
(700, 75),
(1000, 120),
(1500, 160)";

$query2 = mysqli_query($conn, $sql2);

if ($query2) {
    echo "Records created successfully";
} else {
    echo "Error creating records: " . mysqli_error($conn);
}
 
?>