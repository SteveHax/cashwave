<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "withdrawal_data";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Create Table
$sql = "CREATE TABLE withdrawal_history (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
amount INT(6) NOT NULL,
timestamp INT(20) NOT NULL
)";

if ($conn->query($sql) === TRUE) {
  echo "Table created successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?>