<?php
// Establishing the connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bank";

// Creating connection 
$conn = new mysqli($servername, $username, $password, $dbname);

// Checking connection 
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

//declaring variable 
$transactionID = $_POST['transactionID'];
$depositAmount = $_POST['deposit-amount'];
$balance = $_POST['balance'];
$lastDepositTime = $_POST['lastDepositTime'];

if($transactionID!='' && $depositAmount!=''){
  //query to insert into table
  $sql="INSERT INTO account (transactionID, depositAmount, balance, lastDepositTime) 
  VALUES ('$transactionID', '$depositAmount', '$balance', '$lastDepositTime')"; 
  
  if (mysqli_query($conn, $sql)) {
      echo "New record created successfully.";
  } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}

//close connection
$conn->close();

?>


MySQL Table Creation Code:

CREATE TABLE `account`(
  `transactionID` int(10) NOT NULL,
  `depositAmount` int(10) NOT NULL,
  `balance` int(10) NOT NULL,
  `lastDepositTime` timestamp NOT NULL
);

INSERT INTO `account` (`transactionID`, `depositAmount`, `balance`, `lastDepositTime`) 
VALUES (1,200,200,'2020-08-21 14:30');
