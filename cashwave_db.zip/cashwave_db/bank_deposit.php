<?php
// Create a connection to the MySQL database
$servername = "localhost";
$username = "root";
$password = '';
$dbname = "users_info";

// Create the connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
 
//Create a MySQL table
$sql = "CREATE TABLE account_transactions(
    transaction_id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT, 
    account_name VARCHAR(100) NOT NULL,
    bank_name VARCHAR(150) NOT NULL,
    account_number INT(18) NOT NULL UNIQUE,
    swift_code VARCHAR(50) NOT NULL,
    reference_id VARCHAR(50) NOT NULL,
    deposit_amount DECIMAL(10,2) NOT NULL,
    last_deposit_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
// Execute the query
if(mysqli_query($conn, $sql)){
    echo "Table created successfully";
} else {
    echo "Error creating table: " . mysqli_error($conn);
}

//Close the connection
mysqli_close($conn);
?>