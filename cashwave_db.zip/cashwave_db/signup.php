CREATE TABLE users (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    phone VARCHAR(20),
    password VARCHAR(50),
    invitation_code VARCHAR(10),
    unique_code VARCHAR(10)
); 
```

<?php
    if (isset($_POST['submit'])){
        $phone = $_POST['tel'];
        $pass = $_POST['first'];
        $confirmpass = $_POST['sec'];
        $invitationCode = $_POST['invitation'];
        $uniqueCode = $_POST['unique'];

        //validation goes here 
        //if validation is successful then 
        $sql = "INSERT INTO users (phone,password,invitation_code,unique_code) VALUES ('$phone','$pass','$invitationCode','$uniqueCode')";
        $result = mysqli_query($conn,$sql);
        if($result){
            echo "Successfully inserted record";
        }else{
            echo "Error while inserting record";
        }
    }
?>